#ifndef _NIST_ERF_H_
#define _NIST_ERF_H_

double nist_erf(const double);
double nist_erfc(const double);

#endif